title: 记一次docker引起的服务器磁盘占满的问题
date: '2019-12-10 14:48:13'
updated: '2019-12-12 01:40:03'
tags: [Linux, docker, Exception]
permalink: /articles/2019/12/10/1575960493018.html
---



![](https://img.hacpai.com/bing/20180703.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 问题
昨天做了内网穿透后，成功通过我的服务器访问到了内网站点，今早准备登上服务器去完善东西的时候，突然发现，服务器磁盘满了。图示如下：

![1.png](https://img.hacpai.com/file/2019/12/1-a6139406.png)

### 分析问题
正好前一阵看了Linux的磁盘管理命令，这次终于派上用场了（真心不希望呀  :joy:），好吧，先看看怎么回事吧。输入 `df -h`，结果如下：

![2.png](https://img.hacpai.com/file/2019/12/2-11872adc.png)

看见 /dev/vda1 Used 50G , 瞬间惊了，这不就是我的系统盘嘛，这也真的太满了吧！！然后 `cd /`进入根目录开始排查是哪个文件占据了大量的空间。进入根目录后 执行` du -sh * `（这里也可用 `du -sh * | sort -rh`，让结果排序）。输出如下：

![3.png](https://img.hacpai.com/file/2019/12/3-42bd6b37.png)

从输出中可以看到 **var目录** 使用了 47G，看见var这么大，这时心中就已经猜到肯定是某个服务在那里作祟。进入var目录看一下究竟是谁在那捣乱吧。

![4.png](https://img.hacpai.com/file/2019/12/4-2ffefa58.png)

这里可以看到**lib目录**使用46G，好，接着深入，看看究竟怎么回事

![5.png](https://img.hacpai.com/file/2019/12/5-5856a726.png)

进入lib后，再次执行 `du -sh *`,这时罪魁祸首已经出来了。docker引起的，为什么会这样呢。我的docker里面只运行了一个solo博客，怎么会这么大？？于是接着进入docker

![6.png](https://img.hacpai.com/file/2019/12/6-04087ba0.png)

可以看到containers高达45g，这明显是容器的问题了，然后继续进入containers


![7.png](https://img.hacpai.com/file/2019/12/7-a6672387.png)

看见beee7这个容器占了45g之多，然后进入该目录

![8.png](https://img.hacpai.com/file/2019/12/8-be4d89a7.png)

执行 `du -sh *` 然后罪魁祸首就出现了，名为beee7这个文件占了整整45g，而这正是该容器应用的日志文件。这时候我们只是找到了磁盘占满是由于docker中的日志文件引起的。但是并不知道究竟是什么原因导致该应用一直输出日志。这时候由于日志文件太打，不能全部打开访问，我们就可以采用 `tail -n 行数 file`命令来提取日志文件的尾部多少行进一步的分析。

### 解决问题

在分析完毕找到原因过后，我们就可以将日志文件清空了，这时可以用命令`cat /var/null>file`.这里需要注意的是不能使用`rm -rf file` 删除日志文件，如果你执行这个命令删除文件后，通过`df -h`会发现磁盘空间并没有释放，原因是在Linux或者Unix系统中，通过`rm -rf`或者文件管理器删除文件，将会从文件系统的目录结构上解除链接（unlink）。如果文件是被打开的（有一个进程正在使用），那么进程将仍然可以读取该文件，磁盘空间也一直被占用。

----------------------

### 如何预防

虽然说这样做可以解决问题，那也只是治标不治本，难道下次再次发生这样的问题我又要来重复这样的工作吗？不，我懒，不愿意再做这样的事情了。所以我想让日志文件的大小受到限制，不让它有膨胀的机会。通过docker的相关文档，发现我们我们可以修改docker的配置来限制日志文件的大小。

#### 全局配置

新建/etc/docker/daemon.json，若有就不用新建了。添加log-dirver和log-opts参数，样例如下：
```json
{
  "log-driver":"json-file",
  "log-opts": {"max-size":"500m", "max-file":"5"}
}
```
max-size=500m，意味着一个容器日志大小上限是500M，   
max-file=5，意味着一个容器有五个日志，分别是id+.json、id+1.json、id+2.json等。

这样配置过后，重启docker的守护线程。**以后新建的容器都会有效**，但是如果我不想删除现在的容器重新建立一个又该怎么办？

#### 设置一个容器服务的日志大小上限

上述方法，日志文件迟早又会涨回来。要从根本上解决问题，需要限制容器服务的日志大小上限。这个通过配置容器docker-compose的max-size选项来实现

```yml
  logging: 
    driver: “json-file” 
    options: 
      max-size: “3g” 
```
重启容器之后，其日志文件的大小就被限制在3GB，再也不用担心了。










