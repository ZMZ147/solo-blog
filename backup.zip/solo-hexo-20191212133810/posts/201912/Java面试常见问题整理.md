title: Java面试常见问题整理
date: '2019-12-11 23:23:36'
updated: '2019-12-12 00:05:27'
tags: [JAVA, Interview]
permalink: /articles/2019/12/11/1576077816315.html
---
![](https://img.hacpai.com/bing/20180322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

记录一些常见的面试题，为以后面试做准备

2019 - 12 -11

-----------
### 1.jdk，jre的区别是什么？jvm又是什么？
JDK:　`Java Development ToolKit`(Java开发工具包)。JDK是整个JAVA的核心，*包括了Java运行环境（Java Runtime Envirnment），一堆Java工具（javac/java/jdb等）和Java基础的类库（即Java API 包括rt.jar）*。可以让开发者开发，编译，执行Java应用程序

JRE:`Java Runtime Enviromental`(java运行时环境)。也就是我们说的JAVA平台，所有的Java程序都要在JRE下才能运行。包括JVM和JAVA核心类库和支持文件。**与JDK相比，它不包含开发工具——编译器、调试器和其它工具。**

JVM：`Java Virtual Mechinal`(JAVA虚拟机)。JVM是JRE的一部分，它是一个虚构出来的计算机，是通过在实际的计算机上仿真模拟各种计算机功能来实现的。

### 2.`static`关键字是什么意思？Java中是否可以覆盖（override）一个`private`或者是`static`的方法？

在Java中变量的类型有类变量，成员变量，局部变量，用`static`修饰的变量即是类变量，他不属于类的具体实例，而是属于类的。

Java中的`private`方法不能被覆盖，因为`private`修饰的变量或者方法只在当前类中可以访问，如果是其他的类继承当前类是不能访问到`private`变量或者方法的，因此当然不能覆盖。

Java中的`static`方法也不能被覆盖，因为方法覆盖是基于运行时动态绑定的，而`static`方法是编译时静态绑定的。`static`方法跟类的任何实例都不相关，所以概念上不适用。

### 3.是否可以在`static`环境中访问非`static`变量？
`static`变量在Java中是属于类的，他在所有的实例中的值都是一样的，当类被Java虚拟机载入的时候，会对`static`变量进行初始化。如果你的代码尝试不用实例来访问非`static`的变量，编译器会报错，因为这些变量还没有被创建出来，还没有跟任何实例绑定。所以不可以在`static`环境中访问非`static`变量

### 4.Java中支持的数据类型有哪些？什么是自动拆装箱？
Java中一共有两大类数据类型，一种是基本数据类型，一种是引用数据类型。其中基本数据类型有8种，它们分别是，`byte`,`short`,`int`,`long`,`float`,`double`,`boolean`,`char`，除了8种基本数据类型外，还有3种引用类型，它们分别是，类，接口，数组

自动装箱是Java编译器在基本数据类型和对应的包装类型之间做得一个转化。比如: 把`int`转化为`Integer`，`double`转化为`Double`，等等。反之就是自动拆箱。

