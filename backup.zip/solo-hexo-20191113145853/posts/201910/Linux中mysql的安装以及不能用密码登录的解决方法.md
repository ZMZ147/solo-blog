title: Linux中mysql的安装以及不能用密码登录的解决方法
date: '2019-10-28 05:20:31'
updated: '2019-10-28 06:43:41'
tags: [MySQL, Linux]
permalink: /articles/2019/10/28/1572211231161.html
---
  之前通过命令在Linux上安装mysql的时候，每次安装成功过后，即使使用root权限免密登录mysql，将mysql的密码修改成自己的密码后，还是不能通过普通用户验证mysql账户密码的方式登录mysql。在经过一些尝试之后终于成功的以普通用户以及可以远程访问数据库。

不能用密码登录的主要原因：root的plugin被修改成了auth_socket，用密码登陆的plugin应该是mysql_native_password


## 1.配置mysql的普通用户登录

 以ubuntu为例，首先通过命令行安装mysql服务

```shell
sudo apt install mysql-server
```

安装完成后，更改mysql root账户认证模式

```mysql
#更改mysql root的密码以及登录方式
update mysql.user 
set authentication_string=PASSWORD('新密码'),plugin='mysql_native_password'
where user='root';
#刷新
flush privileges;
#退出mysql
exit
```

重启mysql

```shell
sudo service mysql restart 
```

普通方式登录

```shell
mysql -uroot -p
```

然后通过输入密码你就可以进入mysql了。

## 2.配置mysql的远程访问

首先登录进mysql，然后执行修改权限命令

```mysql
#修改权限
grant all on *.* to root@'%' identified by '密码' with grant option;
#刷新
flush privileges;
#退出mysql
exit
```

最后修改侦听地址127.0.0.1为0.0.0.0

```shell
#修改侦听地址127.0.0.1为0.0.0.0
#打开mysql的配置文件
sudo vim /etc/mysql/mysql.conf.d/mysqld.cnf
```

然后将**bind-address = 127.0.0.1**修改为**bind-address = 0.0.0.0**

然后再次重启mysql服务

```shell
sudo service mysql restart 
```

就可以根据提供的mysql的ip，账户密码远程登录mysql了。
