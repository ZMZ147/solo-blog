title: Python中的闭包以及装饰器的使用
date: '2019-10-20 01:21:50'
updated: '2019-10-20 01:21:50'
tags: [python]
permalink: /articles/2019/10/20/1571505710722.html
---
![](https://img.hacpai.com/bing/20180207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 闭包 

求两个数的和用一般的写法为

```python
def add(a,b)
	return a+b
```

用闭包的方式

```python
def sum(a):
    def add(b):
        return a+b
    return add
  # add函数名的引用
```

<!-- more-->

用闭包来实现一个计数器

```python
def counter(FIRST=0):
	cnt = [FIRST]
	def add_one():
		cnt[0] += 1
		return cnt[0]
	return add_one
```

闭包的一般模式

```python
# 函数的闭包
# 套路为
# def funtion1():
# 	funtion1的代码块
# 	def function2():
#       function2的代码
# 		return 返回function2的值
# 	return function2
```

闭包的lambda形式

```python
# a*x+b=y
# 闭包的一般写法
def a_line(a,b):
	def arg_y(x):
		return a*x+b
	return arg_y
# 闭包的lambda方式写法
def a_line1(a,b):
	return  lambda x:a*x+b
```

#### 装饰器

```python
# 利用装饰器实现输出函数的调用时间

import time

# 先定义装饰函数

def timmer(func):
	def wrapper():
		start_time = time.time()
		func()
		end_time = time.time()
		print('%s 运行时间是 %s' %(func.__name__,end_time-start_time))
	return wrapper

@timmer
def I_can_sleep(): #被装饰函数
	time.sleep(3)

I_can_sleep()

# 装饰器的模板()被装饰函数无参数

# def wai(func):
# 	def nei():
# 		start
# 		func()
# 		stop
# 	return  nei


# 装饰器的模板（）被装饰函数有两个参数

# def wai(func):
# 	def nei(a,b):
# 		start
# 		func()
# 		stop
# 	return  nei

#装饰器的模板，装饰器函数有参数

# def new_wai(argv):
# 	def wai(func):
# 		def nei(a,b):
# 			start
# 			func()
# 			stop
# 		return  nei
# 	return wai

# 装饰器中获取到被装饰函数的名字，用 func.__name__

# def wai(func):
# 	def nei():
# 		start
# 		print(func.__name__)
# 		stop
# 	return  nei
```


