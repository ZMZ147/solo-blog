title: 教你利用短URL替换solo博客的长URL！！！
date: '2019-12-06 22:56:50'
updated: '2019-12-07 09:18:46'
tags: [JAVA, Utils]
permalink: /articles/2019/12/06/1575644210365.html
---
 ![](https://img.hacpai.com/bing/20181123.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### Why do this ？

博客写好了之后也需要经常的去回顾，所以我也经常在手机上浏览自己的博客加深对知识的印象，可是每次阅读到最后的时候，那一排长长的地址的布局让人绝望，于是我就想能不能通过将长URL转换为短URL，使得页面更加的简练。
**让人难受的布局：**

![深度截图选择区域20191206225434.png](https://img.hacpai.com/file/2019/12/深度截图选择区域20191206225434-0e7e0333.png)

**转换后的布局：**

![深度截图选择区域20191206225609.png](https://img.hacpai.com/file/2019/12/深度截图选择区域20191206225609-c8372fcf.png)

### How to do？
在早之前自己就准备弄一个短网址转换的工具（虽然网上有很多，但是自己写真的很想写！！！），这次博客这地址就让我直接动工了，然后直接查找相关的博客看看别人怎么实现的。这里参考了[短网址(short URL)系统的原理及其实现](https://www.cnblogs.com/yuanjiangw/p/9791855.html)
刚开始本来是想写个前端页面输入长URL得到短URL，直接将转换后的短URL放在那个位置，但是自己真不太会，写来好丑。。。于是就想直接调用一个接口返回js，然后这个js去获取a标签的值，然后在将该值通过js原生ajax调用另一个接口得到转换后的短URL，再将URL写入a标签。
### How to use
#### （1）话不多说，可以直接直接用我搭的服务
给文章的签名档上的地址a标签一个`id=“url”`，然后调用我的服务返回一个js脚本即可。
代码示例如下：
```js
地址：<a href="{url}" target="_blank" id="url">{url}</a><br>
<script src="http://surl.zhqy.xyz/url/js" charset="utf-8"></script>
<script>setUrl();</script>
```
图片示例如下：
![深度截图选择区域20191207083126.png](https://img.hacpai.com/file/2019/12/深度截图选择区域20191207083126-1a1a65e1.png)
#### （2）拉取我的源代码，直接修改部署到自己的服务器
githup地址：https://github.com/geektomya/surl.git
欢迎stars呀，顺便帮我看看代码风格，，感觉自己风格不太好:sob::pray:
![深度截图选择区域20191207084301.png](https://img.hacpai.com/file/2019/12/深度截图选择区域20191207084301-e3c15506.png)


##### 数据库配置
`mysql`中新建数据库`surl`，字符集`utf8 -- UTF-8 Unicode`，排序规则`utf8_general_ci`然后运行doc中的数据库脚本
 ##### 项目配置
`application.yml`中修改为你的数据库，然后在Message中修改`INDEX`，`PERURL`，`PERINJS`其中的`PERURL`修改为你的短URL的前缀（我这里后面用nginx监听这个服务，直接写了域名）`PERINJS`同理也可以写成`域名/url/`的形式，这里要注意 `/url/`后面的`/`一定不能少。
#####  服务器配置
```nginx
upstream shortUrl {
    server localhost:8087; # 监听端口
}

server {
    listen       80;
    server_name surl.zhqy.xyz; # 域名

    access_log off;

    location / {
        proxy_pass http://shortUrl$request_uri;
        proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
        client_max_body_size  10m;
    }
}
```
当然这里你需要给你的域名一个新的二级域名解析到这里
##### solo配置
```js
地址：<a href="{url}" target="_blank" id="url">{url}</a><br>
<script src="http://域名/url/js" charset="utf-8"></script>
<script>setUrl();</script>
```
将域名修改为你的域名配置即可
